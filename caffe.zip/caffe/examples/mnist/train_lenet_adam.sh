#!/usr/bin/env sh

./build/tools/caffe train --solver=examples/mnist/lenet_solver_adam.prototxt
