//This file is automatically rebuilt by the Cesium build process.
/*global define*/
define(function() {
    'use strict';
    return "varying vec4 v_color;\n\
\n\
void main()\n\
{\n\
    gl_FragColor = v_color;\n\
}\n\
";
});