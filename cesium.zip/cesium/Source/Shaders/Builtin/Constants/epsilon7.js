//This file is automatically rebuilt by the Cesium build process.
/*global define*/
define(function() {
    'use strict';
    return "/**\n\
 * 0.0000001\n\
 *\n\
 * @name czm_epsilon7\n\
 * @glslConstant\n\
 */\n\
const float czm_epsilon7 = 0.0000001;";
});