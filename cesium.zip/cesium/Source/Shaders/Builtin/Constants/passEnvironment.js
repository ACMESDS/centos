//This file is automatically rebuilt by the Cesium build process.
/*global define*/
define(function() {
    'use strict';
    return "/**\n\
 * The automatic GLSL constant for {@link Pass#ENVIRONMENT}\n\
 *\n\
 * @name czm_passEnvironment\n\
 * @glslConstant\n\
 *\n\
 * @see czm_pass\n\
 */\n\
const float czm_passEnvironment = 0.0;";
});