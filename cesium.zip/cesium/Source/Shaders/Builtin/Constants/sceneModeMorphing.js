//This file is automatically rebuilt by the Cesium build process.
/*global define*/
define(function() {
    'use strict';
    return "/**\n\
 * The constant identifier for the Morphing {@link SceneMode}\n\
 *\n\
 * @name czm_sceneModeMorphing\n\
 * @glslConstant\n\
 * @see czm_sceneMode\n\
 * @see czm_sceneMode2D\n\
 * @see czm_sceneModeColumbusView\n\
 * @see czm_sceneMode3D\n\
 */\n\
const float czm_sceneModeMorphing = 0.0;";
});