//This file is automatically rebuilt by the Cesium build process.
/*global define*/
define(function() {
    'use strict';
    return "/**\n\
 * 0.0001\n\
 *\n\
 * @name czm_epsilon4\n\
 * @glslConstant\n\
 */\n\
const float czm_epsilon4 = 0.0001;";
});