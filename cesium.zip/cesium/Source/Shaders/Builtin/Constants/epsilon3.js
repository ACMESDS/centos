//This file is automatically rebuilt by the Cesium build process.
/*global define*/
define(function() {
    'use strict';
    return "/**\n\
 * 0.001\n\
 *\n\
 * @name czm_epsilon3\n\
 * @glslConstant\n\
 */\n\
const float czm_epsilon3 = 0.001;";
});