#ifndef ZXOVER_H
#define ZXOVER_H

#define ATL_3NB 132
#define NN_MNK_M 63536
#define NN_MNK_N 4400
#define NN_MNK_MN 19360
#define NN_MNK_K 39600
#define NN_MNK_GE 54872
#define NT_MNK_M 4400
#define NT_MNK_N 9900
#define NT_MNK_MN 19360
#define NT_MNK_K 9900
#define NT_MNK_GE 13824
#define TN_MNK_M 4400
#define TN_MNK_N 4400
#define TN_MNK_MN 19360
#define TN_MNK_K 25344
#define TN_MNK_GE 54872
#define TT_MNK_M 4400
#define TT_MNK_N 4400
#define TT_MNK_MN 19360
#define TT_MNK_K 9900
#define TT_MNK_GE 13824
#define C2R_K 255

#endif
