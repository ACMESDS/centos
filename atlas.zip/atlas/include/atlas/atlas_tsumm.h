#ifndef ATLAS_SUMM_H
   #define ATLAS_SUMM_H
#define ATL_TAFFINITY 1
#define ATL_ATOMIC_COUNT_MUT 0
#endif
