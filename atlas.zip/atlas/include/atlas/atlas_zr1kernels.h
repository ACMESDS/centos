/*
 * This file generated on line 730 of /home/jamesdb/installs/ATLAS/build/..//tune/blas/ger/r1hgen.c
 */
#ifndef ATLAS_ZR1KERNELS_H
   #define ATLAS_ZR1KERNELS_H

void ATL_zgerk__900002
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);
void ATL_zgerk__900005
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);
void ATL_zgerk__900007
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);
void ATL_zgerk__900006
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);
void ATL_zgerk__900005
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);
void ATL_zgerk__900007
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);
void ATL_zgerk__900006
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);
void ATL_zgerk__900002
   (ATL_CINT, ATL_CINT, const double*, const double*, double*, ATL_CINT);


#endif /* end guard around atlas_zr1kernels.h */
