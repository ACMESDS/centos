#ifndef CXOVER_H
#define CXOVER_H

#define ATL_3NB 216
#define NN_MNK_M 41472
#define NN_MNK_N 103968
#define NN_MNK_MN 51840
#define NN_MNK_K 103968
#define NN_MNK_GE 54872
#define NT_MNK_M 16200
#define NT_MNK_N 16200
#define NT_MNK_MN 51840
#define NT_MNK_K 64800
#define NT_MNK_GE 27000
#define TN_MNK_M 103968
#define TN_MNK_N 103968
#define TN_MNK_MN 51840
#define TN_MNK_K 103968
#define TN_MNK_GE 54872
#define TT_MNK_M 103968
#define TT_MNK_N 41472
#define TT_MNK_MN 51840
#define TT_MNK_K 103968
#define TT_MNK_GE 54872
#define C2R_K 99

#endif
