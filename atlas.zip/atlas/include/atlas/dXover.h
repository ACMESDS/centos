#ifndef DXOVER_H
#define DXOVER_H

#define ATL_3NB 156
#define NN_MNK_M 146068
#define NN_MNK_N 146068
#define NN_MNK_MN 27040
#define NN_MNK_K 146068
#define NN_MNK_GE 148877
#define NT_MNK_M 146068
#define NT_MNK_N 11700
#define NT_MNK_MN 27040
#define NT_MNK_K 29952
#define NT_MNK_GE 54872
#define TN_MNK_M 146068
#define TN_MNK_N 146068
#define TN_MNK_MN 27040
#define TN_MNK_K 146068
#define TN_MNK_GE 148877
#define TT_MNK_M 146068
#define TT_MNK_N 146068
#define TT_MNK_MN 27040
#define TT_MNK_K 75088
#define TT_MNK_GE 148877

#endif
